/* ============================================================
   THEME TOGGLE
   ============================================================ */
const themeToggle = document.getElementById('themeToggle');
const iconMoon = document.getElementById('iconMoon');
const iconSun = document.getElementById('iconSun');
const htmlEl = document.documentElement;

const savedTheme = localStorage.getItem('theme') || 'dark';
htmlEl.setAttribute('data-theme', savedTheme);
updateThemeIcon(savedTheme);

themeToggle?.addEventListener('click', () => {
  const current = htmlEl.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  htmlEl.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  updateThemeIcon(next);
});

function updateThemeIcon(theme) {
  if (!iconMoon || !iconSun) return;
  iconMoon.style.display = theme === 'dark' ? 'block' : 'none';
  iconSun.style.display = theme === 'light' ? 'block' : 'none';
}

/* ============================================================
   LOGIN (hanya jalan di index.html)
   ============================================================ */
const loginForm = document.getElementById('loginForm');

if (loginForm) {
  const loginError = document.getElementById('loginError');

  // ====== ADMIN HARDCODE (biar gak butuh fetch) ======
  const ADMIN_USER = 'Adminnn';
  const ADMIN_PASS = 'ADMINN';

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.textContent = '';

    const nama = document.getElementById('nama').value.trim();
    const nisn = document.getElementById('nisn').value.trim();
    const password = document.getElementById('password').value.trim();

    console.log('[LOGIN] Input:', { nama, nisn, password });

    if (!nama) {
      loginError.textContent = 'Nama wajib diisi.';
      return;
    }

    // ============================
    // 1. CEK ADMIN (HARDCODE — GAK BUTUH FETCH)
    // ============================
    if (
      nama.toLowerCase() === ADMIN_USER.toLowerCase() &&
      password === ADMIN_PASS
    ) {
      console.log('[LOGIN] Admin login sukses');
      localStorage.setItem('role', 'admin');
      localStorage.setItem('nama', ADMIN_USER);
      localStorage.setItem('nisn', '-');
      window.location.href = 'dashboard.html';
      return;
    }

    // ============================
    // 2. CEK SISWA (HANYA kalau bukan admin)
    // ============================
    if (!nisn) {
      loginError.textContent = 'Nama/Password admin salah, atau NISN siswa belum diisi.';
      return;
    }

    try {
      const siswaRes = await fetch('database/siswa-siswi.json');
      if (!siswaRes.ok) throw new Error('HTTP ' + siswaRes.status);
      const siswaList = await siswaRes.json();

      const siswa = siswaList.find(
        (s) =>
          s.nama.toLowerCase() === nama.toLowerCase() &&
          String(s.nisn) === nisn
      );

      if (siswa) {
        localStorage.setItem('role', 'siswa');
        localStorage.setItem('nama', siswa.nama);
        localStorage.setItem('nisn', siswa.nisn);
        window.location.href = 'dashboard.html';
      } else {
        loginError.textContent = 'Data siswa tidak ditemukan. Periksa nama & NISN.';
      }
    } catch (err) {
      console.error('[LOGIN] Gagal load siswa:', err);
      loginError.textContent = 'Gagal memuat data siswa. Pastikan folder database ada.';
    }
  });
}

/* ============================================================
   DASHBOARD
   ============================================================ */
const isDashboard = document.body.classList.contains('dash-body');

if (isDashboard) {
  // Cek session
  const role = localStorage.getItem('role');
  const namaUser = localStorage.getItem('nama') || '';
  const nisnUser = localStorage.getItem('nisn') || '';

  if (!role) {
    window.location.href = 'index.html';
  }

  // Inisial profile
  function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  document.getElementById('profileInitial').textContent = getInitials(namaUser);

  // Tampilkan elemen sesuai role
  if (role === 'admin') {
    document.getElementById('hamburgerBtn').classList.remove('hidden');
  } else if (role === 'siswa') {
    document.getElementById('notifBtn').classList.remove('hidden');
  }

  /* ============================================================
     NAVIGASI
     ============================================================ */
  const navLinks = document.querySelectorAll('.nav-link');
  const pages = document.querySelectorAll('.page');

  function showPage(name) {
    pages.forEach(p => p.classList.remove('active'));
    document.getElementById(`page-${name}`)?.classList.add('active');

    navLinks.forEach(l => {
      l.classList.toggle('active', l.dataset.page === name);
    });

    if (name === 'siswa') loadSiswa();
    if (name === 'guru') loadGuru();
    if (name === 'mapel') loadMapel();
    if (name === 'pengurus') loadPengurus();
    if (name === 'profile') loadProfile();
  }

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      showPage(link.dataset.page);
    });
  });

  // Klik profile
  document.getElementById('profileBtn').addEventListener('click', () => {
    showPage('profile');
  });

  /* ============================================================
     LOAD DATA DARI JSON (cache)
     ============================================================ */
  let cacheSiswa = null;
  let cacheGuru = null;
  let cacheMapel = null;
  let cachePengurus = null;

  async function fetchJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`Gagal load ${path}`);
    return await res.json();
  }

  /* ============================================================
     DB SISWA
     ============================================================ */
  async function loadSiswa() {
    if (!cacheSiswa) cacheSiswa = await fetchJSON('database/siswa-siswi.json');
    renderSiswa();

    // Isi dropdown asal (sekali saja)
    const asalSelect = document.getElementById('filterAsal');
    if (asalSelect.options.length <= 1) {
      const asalSet = [...new Set(cacheSiswa.map(s => s.asal))].sort();
      asalSet.forEach(a => {
        const opt = document.createElement('option');
        opt.value = a;
        opt.textContent = a;
        asalSelect.appendChild(opt);
      });
    }
  }

  function renderSiswa() {
    const gender = document.getElementById('filterGender').value;
    const asal = document.getElementById('filterAsal').value;
    const search = document.getElementById('searchSiswa').value.toLowerCase();

    const filtered = cacheSiswa.filter(s => {
      if (gender !== 'all' && s.gender !== gender) return false;
      if (asal !== 'all' && s.asal !== asal) return false;
      if (search && !s.nama.toLowerCase().includes(search) && !s.nisn.includes(search)) return false;
      return true;
    });

    const tbody = document.getElementById('tbodySiswa');
    const empty = document.getElementById('emptySiswa');
    tbody.innerHTML = '';

    if (filtered.length === 0) {
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');

    filtered.forEach((s, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${i + 1}</td>
        <td>${s.nama}</td>
        <td>${s.nisn}</td>
        <td>${s.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</td>
        <td>${s.tempatLahir}</td>
        <td>${s.tanggalLahir}</td>
        <td>${s.umur}</td>
        <td>${s.agama}</td>
        <td>${s.asal}</td>
        <td>${s.alamat}</td>
        <td>${s.namaAyah}</td>
        <td>${s.namaIbu}</td>
        <td>${s.noHp}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  ['filterGender', 'filterAsal', 'searchSiswa'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', renderSiswa);
    document.getElementById(id)?.addEventListener('change', renderSiswa);
  });

  document.getElementById('resetFilterSiswa')?.addEventListener('click', () => {
    document.getElementById('filterGender').value = 'all';
    document.getElementById('filterAsal').value = 'all';
    document.getElementById('searchSiswa').value = '';
    renderSiswa();
  });

  /* ============================================================
     DB GURU
     ============================================================ */
  async function loadGuru() {
    if (!cacheGuru) cacheGuru = await fetchJSON('database/guru.json');
    const tbody = document.getElementById('tbodyGuru');
    tbody.innerHTML = '';
    cacheGuru.forEach((g, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${i + 1}</td>
        <td>${g.nama}</td>
        <td>${g.jabatan}</td>
        <td>${g.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</td>
        <td>${g.mapel}</td>
        <td>${g.noHp}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  /* ============================================================
     DB MAPEL
     ============================================================ */
  async function loadMapel() {
    if (!cacheMapel) cacheMapel = await fetchJSON('database/mapel.json');
    const container = document.getElementById('mapelContainer');
    container.innerHTML = '';
    cacheMapel.forEach(m => {
      const card = document.createElement('div');
      card.className = 'mapel-card glass';
      card.innerHTML = `
        <h3>${m.hari}</h3>
        <ul>${m.mapel.map(x => `<li>${x}</li>`).join('')}</ul>
      `;
      container.appendChild(card);
    });
  }

  /* ============================================================
     DB PENGURUS
     ============================================================ */
  async function loadPengurus() {
    if (!cachePengurus) cachePengurus = await fetchJSON('database/pengurus.json');
    renderPengurus();
  }

  function renderPengurus() {
    const bagian = document.getElementById('filterBagian').value;
    const gender = document.getElementById('filterGenderPengurus').value;

    const filtered = cachePengurus.filter(p => {
      if (bagian !== 'all' && p.bagian !== bagian) return false;
      if (gender !== 'all' && p.gender !== gender) return false;
      return true;
    });

    const tbody = document.getElementById('tbodyPengurus');
    tbody.innerHTML = '';
    filtered.forEach((p, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${i + 1}</td>
        <td>${p.nama}</td>
        <td>${p.namaLengkap}</td>
        <td>${p.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</td>
        <td>${p.bagian}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  ['filterBagian', 'filterGenderPengurus'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', renderPengurus);
  });

  document.getElementById('resetFilterPengurus')?.addEventListener('click', () => {
    document.getElementById('filterBagian').value = 'all';
    document.getElementById('filterGenderPengurus').value = 'all';
    renderPengurus();
  });

  /* ============================================================
     PROFILE
     ============================================================ */
  async function loadProfile() {
    if (!cacheSiswa) cacheSiswa = await fetchJSON('database/siswa-siswi.json');

    document.getElementById('profileAvatarBig').textContent = getInitials(namaUser);
    document.getElementById('profileName').textContent = namaUser;
    document.getElementById('profileRole').textContent = role === 'admin' ? 'Administrator' : 'Siswa';

    document.getElementById('infoNama').textContent = namaUser;
    document.getElementById('infoRole').textContent = role === 'admin' ? 'Administrator' : 'Siswa';

    if (role === 'siswa') {
      const s = cacheSiswa.find(x => x.nisn === nisnUser);
      if (s) {
        document.getElementById('infoNisn').textContent = s.nisn;
        document.getElementById('infoGender').textContent = s.gender === 'L' ? 'Laki-laki' : 'Perempuan';
        document.getElementById('infoTempat').textContent = s.tempatLahir;
        document.getElementById('infoTgl').textContent = s.tanggalLahir;
        document.getElementById('infoUmur').textContent = s.umur + ' tahun';
        document.getElementById('infoAgama').textContent = s.agama;
        document.getElementById('infoAsal').textContent = s.asal;
        document.getElementById('infoAlamat').textContent = s.alamat;
        document.getElementById('infoAyah').textContent = s.namaAyah;
        document.getElementById('infoIbu').textContent = s.namaIbu;
      }
    } else {
      document.getElementById('infoNisn').textContent = '-';
      document.getElementById('infoGender').textContent = '-';
      document.getElementById('infoTempat').textContent = '-';
      document.getElementById('infoTgl').textContent = '-';
      document.getElementById('infoUmur').textContent = '-';
      document.getElementById('infoAgama').textContent = '-';
      document.getElementById('infoAsal').textContent = '-';
      document.getElementById('infoAlamat').textContent = '-';
      document.getElementById('infoAyah').textContent = '-';
      document.getElementById('infoIbu').textContent = '-';
    }
  }

  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = 'index.html';
  });

  /* ============================================================
     SIDEBAR ADMIN
     ============================================================ */
  const sidebar = document.getElementById('adminSidebar');
  const overlay = document.getElementById('sidebarOverlay');

  document.getElementById('hamburgerBtn')?.addEventListener('click', () => {
    sidebar.classList.add('open');
    overlay.classList.remove('hidden');
  });

  function closeSidebar() {
    sidebar.classList.remove('open');
    overlay.classList.add('hidden');
  }

  document.getElementById('closeSidebar')?.addEventListener('click', closeSidebar);
  overlay?.addEventListener('click', closeSidebar);

  /* ============================================================
     MODAL ADMIN
     ============================================================ */
  const adminModal = document.getElementById('adminModal');
  const adminModalTitle = document.getElementById('adminModalTitle');
  const adminModalBody = document.getElementById('adminModalBody');

  document.getElementById('closeAdminModal')?.addEventListener('click', () => {
    adminModal.classList.add('hidden');
  });

  adminModal?.addEventListener('click', (e) => {
    if (e.target === adminModal) adminModal.classList.add('hidden');
  });

  function openAdminModal(title, bodyHTML) {
    adminModalTitle.textContent = title;
    adminModalBody.innerHTML = bodyHTML;
    adminModal.classList.remove('hidden');
  }

  document.querySelectorAll('[data-admin]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      closeSidebar();
      const type = link.dataset.admin;
      handleAdminMenu(type);
    });
  });

  function handleAdminMenu(type) {
    if (type === 'addAdmin') {
      openAdminModal('Tambah Admin', `
        <form id="formAddAdmin">
          <div class="form-row">
            <label>Username</label>
            <input type="text" id="newAdminUser" required />
          </div>
          <div class="form-row">
            <label>Password</label>
            <input type="text" id="newAdminPass" required />
          </div>
          <button type="submit" class="btn-primary">Simpan</button>
          <p class="form-msg" id="msgAddAdmin"></p>
        </form>
      `);
      document.getElementById('formAddAdmin').addEventListener('submit', (ev) => {
        ev.preventDefault();
        const u = document.getElementById('newAdminUser').value.trim();
        const p = document.getElementById('newAdminPass').value.trim();
        const msg = document.getElementById('msgAddAdmin');
        const admins = JSON.parse(localStorage.getItem('adminList') || '[]');
        if (admins.some(a => a.username.toLowerCase() === u.toLowerCase()) ||
            u.toLowerCase() === 'adminnn') {
          msg.textContent = 'Username sudah dipakai.';
          msg.className = 'form-msg err';
          return;
        }
        admins.push({ id: admins.length + 1, username: u, password: p });
        localStorage.setItem('adminList', JSON.stringify(admins));
        msg.textContent = 'Admin ditambahkan (tersimpan di browser).';
        msg.className = 'form-msg ok';
      });
    }

    if (type === 'addSiswa') {
      openAdminModal('Tambah Data Siswa', `
        <form id="formAddSiswa">
          <div class="form-row"><label>Nama</label><input type="text" id="sNama" required /></div>
          <div class="form-row"><label>NISN</label><input type="text" id="sNisn" required /></div>
          <div class="form-row">
            <label>Gender</label>
            <select id="sGender"><option value="L">Laki-laki</option><option value="P">Perempuan</option></select>
          </div>
          <div class="form-row"><label>Tempat Lahir</label><input type="text" id="sTempat" /></div>
          <div class="form-row"><label>Tanggal Lahir</label><input type="date" id="sTgl" /></div>
          <div class="form-row"><label>Umur</label><input type="number" id="sUmur" /></div>
          <div class="form-row"><label>Agama</label><input type="text" id="sAgama" value="ISLAM" /></div>
          <div class="form-row"><label>Asal</label><input type="text" id="sAsal" /></div>
          <div class="form-row"><label>Alamat</label><input type="text" id="sAlamat" /></div>
          <div class="form-row"><label>Nama Ayah</label><input type="text" id="sAyah" /></div>
          <div class="form-row"><label>Nama Ibu</label><input type="text" id="sIbu" /></div>
          <div class="form-row"><label>No HP</label><input type="text" id="sHp" /></div>
          <button type="submit" class="btn-primary">Simpan</button>
          <p class="form-msg" id="msgAddSiswa"></p>
        </form>
      `);
      document.getElementById('formAddSiswa').addEventListener('submit', (ev) => {
        ev.preventDefault();
        const msg = document.getElementById('msgAddSiswa');
        const newSiswa = {
          no: (cacheSiswa?.length || 0) + 1,
          nama: document.getElementById('sNama').value.trim().toUpperCase(),
          nisn: document.getElementById('sNisn').value.trim(),
          gender: document.getElementById('sGender').value,
          tempatLahir: document.getElementById('sTempat').value.trim().toUpperCase(),
          tanggalLahir: document.getElementById('sTgl').value,
          umur: parseInt(document.getElementById('sUmur').value) || 0,
          agama: document.getElementById('sAgama').value.trim().toUpperCase(),
          namaAyah: document.getElementById('sAyah').value.trim().toUpperCase(),
          namaIbu: document.getElementById('sIbu').value.trim().toUpperCase(),
          noHp: document.getElementById('sHp').value.trim(),
          alamat: document.getElementById('sAlamat').value.trim().toUpperCase(),
          asal: document.getElementById('sAsal').value.trim().toUpperCase(),
          jurusan: 'RPL'
        };
        if (!cacheSiswa) cacheSiswa = [];
        cacheSiswa.push(newSiswa);
        cacheSiswa.sort((a, b) => a.nama.localeCompare(b.nama));
        localStorage.setItem('siswaExtra', JSON.stringify(cacheSiswa));
        msg.textContent = 'Siswa ditambahkan (tersimpan di browser).';
        msg.className = 'form-msg ok';
      });
    }

    if (type === 'kirimNotif') {
      openAdminModal('Kirim Pemberitahuan', `
        <form id="formNotif">
          <div class="form-row">
            <label>Isi Pemberitahuan</label>
            <textarea id="notifPesan" required placeholder="Tulis pesan bebas..."></textarea>
          </div>
          <button type="submit" class="btn-primary">Kirim</button>
          <p class="form-msg" id="msgNotif"></p>
        </form>
      `);
      document.getElementById('formNotif').addEventListener('submit', (ev) => {
        ev.preventDefault();
        const pesan = document.getElementById('notifPesan').value.trim();
        const list = JSON.parse(localStorage.getItem('notifList') || '[]');
        const now = new Date();
        const kadaluarsa = new Date(now.getTime() + 60 * 60 * 1000); // 1 jam
        list.push({
          id: Date.now(),
          pesan,
          pengirim: namaUser,
          waktu: now.toISOString(),
          kadaluarsa: kadaluarsa.toISOString()
        });
        localStorage.setItem('notifList', JSON.stringify(list));
        const msg = document.getElementById('msgNotif');
        msg.textContent = 'Pemberitahuan terkirim.';
        msg.className = 'form-msg ok';
      });
    }

    if (type === 'modifMapel') {
      openAdminModal('Modifikasi Mapel', `<div id="listMapelAdmin"></div>`);
      const list = document.getElementById('listMapelAdmin');
      (cacheMapel || []).forEach((m, i) => {
        const div = document.createElement('div');
        div.className = 'form-row';
        div.innerHTML = `
          <label>${m.hari}</label>
          <input type="text" value="${m.mapel.join(', ')}" data-index="${i}" />
        `;
        list.appendChild(div);
      });
      const btn = document.createElement('button');
      btn.className = 'btn-primary';
      btn.textContent = 'Simpan Perubahan';
      btn.onclick = () => {
        document.querySelectorAll('#listMapelAdmin input').forEach(inp => {
          const i = parseInt(inp.dataset.index);
          cacheMapel[i].mapel = inp.value.split(',').map(x => x.trim()).filter(Boolean);
        });
        localStorage.setItem('mapelExtra', JSON.stringify(cacheMapel));
        alert('Perubahan mapel disimpan di browser.');
      };
      list.appendChild(btn);
    }

    if (type === 'modifGuru') {
      openAdminModal('Modifikasi Guru', `<div id="listGuruAdmin"></div>`);
      const list = document.getElementById('listGuruAdmin');
      (cacheGuru || []).forEach((g, i) => {
        const div = document.createElement('div');
        div.className = 'form-row';
        div.innerHTML = `
          <label>Guru ${i + 1}</label>
          <input type="text" value="${g.nama}" data-field="nama" data-index="${i}" placeholder="Nama" />
          <input type="text" value="${g.jabatan}" data-field="jabatan" data-index="${i}" placeholder="Jabatan" />
          <input type="text" value="${g.mapel}" data-field="mapel" data-index="${i}" placeholder="Mapel" />
        `;
        list.appendChild(div);
      });
      const btn = document.createElement('button');
      btn.className = 'btn-primary';
      btn.textContent = 'Simpan Perubahan';
      btn.onclick = () => {
        document.querySelectorAll('#listGuruAdmin input').forEach(inp => {
          const i = parseInt(inp.dataset.index);
          const f = inp.dataset.field;
          cacheGuru[i][f] = inp.value.trim();
        });
        localStorage.setItem('guruExtra', JSON.stringify(cacheGuru));
        alert('Perubahan guru disimpan di browser.');
      };
      list.appendChild(btn);
    }

    if (type === 'modifPengurus') {
      openAdminModal('Modifikasi Pengurus', `<div id="listPengurusAdmin"></div>`);
      const list = document.getElementById('listPengurusAdmin');
      (cachePengurus || []).forEach((p, i) => {
        const div = document.createElement('div');
        div.className = 'form-row';
        div.innerHTML = `
          <label>${p.bagian}</label>
          <input type="text" value="${p.nama}" data-field="nama" data-index="${i}" placeholder="Nama Panggilan" />
          <input type="text" value="${p.namaLengkap}" data-field="namaLengkap" data-index="${i}" placeholder="Nama Lengkap" />
          <button type="button" class="btn-secondary" data-del="${i}" style="margin-top:6px">Hapus</button>
        `;
        list.appendChild(div);
      });
      list.querySelectorAll('[data-del]').forEach(b => {
        b.addEventListener('click', () => {
          const i = parseInt(b.dataset.del);
          cachePengurus.splice(i, 1);
          localStorage.setItem('pengurusExtra', JSON.stringify(cachePengurus));
          handleAdminMenu('modifPengurus');
        });
      });
      const btn = document.createElement('button');
      btn.className = 'btn-primary';
      btn.textContent = 'Simpan Perubahan';
      btn.onclick = () => {
        document.querySelectorAll('#listPengurusAdmin input').forEach(inp => {
          const i = parseInt(inp.dataset.index);
          const f = inp.dataset.field;
          cachePengurus[i][f] = inp.value.trim();
        });
        localStorage.setItem('pengurusExtra', JSON.stringify(cachePengurus));
        alert('Perubahan pengurus disimpan di browser.');
      };
      list.appendChild(btn);
    }
  }

  /* ============================================================
     NOTIFIKASI (Lonceng siswa)
     ============================================================ */
  const notifBtn = document.getElementById('notifBtn');
  const notifModal = document.getElementById('notifModal');
  const notifList = document.getElementById('notifList');
  const notifBadge = document.getElementById('notifBadge');

  document.getElementById('closeNotifModal')?.addEventListener('click', () => {
    notifModal.classList.add('hidden');
  });

  notifModal?.addEventListener('click', (e) => {
    if (e.target === notifModal) notifModal.classList.add('hidden');
  });

  function getActiveNotifs() {
    const list = JSON.parse(localStorage.getItem('notifList') || '[]');
    const now = new Date();
    const active = list.filter(n => new Date(n.kadaluarsa) > now);
    if (active.length !== list.length) {
      localStorage.setItem('notifList', JSON.stringify(active));
    }
    return active;
  }

  function updateNotifBadge() {
    const active = getActiveNotifs();
    if (active.length > 0) {
      notifBadge.textContent = active.length;
      notifBadge.classList.remove('hidden');
    } else {
      notifBadge.classList.add('hidden');
    }
  }

  function renderNotifList() {
    const active = getActiveNotifs();
    notifList.innerHTML = '';

    if (active.length === 0) {
      notifList.innerHTML = `<p class="notif-empty">Tidak ada pemberitahuan.</p>`;
      return;
    }

    active.forEach(n => {
      const div = document.createElement('div');
      div.className = 'notif-item';
      const waktu = new Date(n.waktu).toLocaleString('id-ID');
      div.innerHTML = `
        <p>${n.pesan}</p>
        <small>Dari: ${n.pengirim} — ${waktu}</small>
        <div class="notif-actions">
          <button data-del-notif="${n.id}">Hapus</button>
          <button data-close-notif>Tutup</button>
        </div>
      `;
      notifList.appendChild(div);
    });

    notifList.querySelectorAll('[data-del-notif]').forEach(b => {
      b.addEventListener('click', () => {
        const id = parseInt(b.dataset.delNotif);
        const list = JSON.parse(localStorage.getItem('notifList') || '[]');
        const filtered = list.filter(n => n.id !== id);
        localStorage.setItem('notifList', JSON.stringify(filtered));
        renderNotifList();
        updateNotifBadge();
      });
    });

    notifList.querySelectorAll('[data-close-notif]').forEach(b => {
      b.addEventListener('click', () => {
        notifModal.classList.add('hidden');
      });
    });
  }

  notifBtn?.addEventListener('click', () => {
    renderNotifList();
    notifModal.classList.remove('hidden');
  });

  // Auto update badge setiap 30 detik
  updateNotifBadge();
  setInterval(updateNotifBadge, 30000);

  /* ============================================================
     LOAD DATA AWAL (merge JSON + localStorage)
     ============================================================ */
  async function initData() {
    // Siswa
    try {
      const siswaBase = await fetchJSON('database/siswa-siswi.json');
      const siswaExtra = JSON.parse(localStorage.getItem('siswaExtra') || 'null');
      cacheSiswa = siswaExtra || siswaBase;
    } catch (err) {
      console.error('Gagal load siswa:', err);
      cacheSiswa = [];
    }

    // Guru
    try {
      const guruBase = await fetchJSON('database/guru.json');
      const guruExtra = JSON.parse(localStorage.getItem('guruExtra') || 'null');
      cacheGuru = guruExtra || guruBase;
    } catch (err) {
      console.error('Gagal load guru:', err);
      cacheGuru = [];
    }

    // Mapel
    try {
      const mapelBase = await fetchJSON('database/mapel.json');
      const mapelExtra = JSON.parse(localStorage.getItem('mapelExtra') || 'null');
      cacheMapel = mapelExtra || mapelBase;
    } catch (err) {
      console.error('Gagal load mapel:', err);
      cacheMapel = [];
    }

    // Pengurus
    try {
      const pengurusBase = await fetchJSON('database/pengurus.json');
      const pengurusExtra = JSON.parse(localStorage.getItem('pengurusExtra') || 'null');
      cachePengurus = pengurusExtra || pengurusBase;
    } catch (err) {
      console.error('Gagal load pengurus:', err);
      cachePengurus = [];
    }

    // Halaman awal
    showPage('siswa');
  }

  initData();
}